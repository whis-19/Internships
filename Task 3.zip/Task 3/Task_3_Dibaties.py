import numpy as np 
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics 
diabetes_df=pd.read_csv('diabetes.csv')

diabetes_df_copy = diabetes_df.copy(deep = True)

diabetes_df_copy[['Glucose','BloodPressure',
                  'SkinThickness','Insulin','BMI']] = diabetes_df_copy[['Glucose',
                    'BloodPressure','SkinThickness','Insulin'
                    ,'BMI']].replace(0,np.NaN) 

X = diabetes_df.drop('Outcome', axis=1)
y = diabetes_df['Outcome']

X_train, X_test, x_train_outcome, y_test = train_test_split(X, y, test_size=0.2, random_state=1) 

dlf=DecisionTreeClassifier(criterion='entropy',max_depth=3) # setting the criterion as entropy and max_depth 3
dlf = dlf.fit(X_train,x_train_outcome)
yy_pred = dlf.predict(X_test)

train_accuracy = dlf.score(X_train, x_train_outcome)

# Evaluate the model on the validation set
val_accuracy = dlf.score(X_test, y_test)


print("Training Accuracy: {:.2f}".format(train_accuracy))
print("Validation Accuracy: {:.2f}".format(val_accuracy))

print("Accuracy:",metrics.accuracy_score(y_test,yy_pred))

